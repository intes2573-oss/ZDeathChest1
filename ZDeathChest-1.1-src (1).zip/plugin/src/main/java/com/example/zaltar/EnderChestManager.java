package com.example.zaltar;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class EnderChestManager implements Listener {

    private final Zaltar plugin;

    private Location activeChestLocation = null;
    private boolean chestIsOpen = false;
    private Inventory deathChestInventory;

    private UUID timerDisplayUUID = null;
    private UUID openDisplayUUID = null;
    private int timerTaskId = -1;
    private int openTimerTaskId = -1;
    private int autoSpawnTaskId = -1;

    private final Map<UUID, Long> lastClickTimes = new HashMap<>();

    private File configFile;
    private FileConfiguration config;

    public EnderChestManager(Zaltar plugin) {
        this.plugin = plugin;
        loadConfig();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    private void loadConfig() {
        configFile = new File(plugin.getDataFolder(), "config.yml");
        if (!configFile.exists()) {
            try { configFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        config = YamlConfiguration.loadConfiguration(configFile);
        config.addDefault("Время.время-до-открытия", 250);
        config.addDefault("Время.время-до-удаления-после-открытия", 30);
        config.addDefault("Время.интервал-авто-спавна-минуты", 60);
        config.options().copyDefaults(true);
        try { config.save(configFile); } catch (IOException e) { e.printStackTrace(); }
    }

    public void setConfig(FileConfiguration newConfig) {
        this.config = newConfig;
    }

    public void spawnEnderChest(Player player) {
        if (activeChestLocation != null) {
            forceRemoveChest();
        }

        String worldName = config.getString("Спавн.world", "spawn");
        int timeopen = config.getInt("Время.время-до-открытия", 250);
        int timedeleteopen = config.getInt("Время.время-до-удаления-после-открытия", 30);

        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            if (player != null) player.sendMessage(ChatColor.RED + "Мир '" + worldName + "' не найден!");
            return;
        }

        double x = config.getDouble("Спавн.x", 100);
        double y = config.getDouble("Спавн.y", 64);
        double z = config.getDouble("Спавн.z", 100);

        Location location = new Location(world, x, y, z);
        activeChestLocation = location;
        chestIsOpen = false;

        deathChestInventory = Bukkit.createInventory(null, 54, ChatColor.DARK_PURPLE + "Death Chest");
        plugin.getLootManager().loadLoot(deathChestInventory);

        location.getBlock().setType(Material.ENDER_CHEST);

        Bukkit.broadcastMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "Сундук смерти появился! " +
                ChatColor.YELLOW + "Откроется через " + formatTime(timeopen));

        createTimerDisplay(location, timeopen);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (activeChestLocation == null) return;
            chestIsOpen = true;
            removeTimerDisplay();
            createOpenDisplay(location, timedeleteopen);
            Bukkit.broadcastMessage(ChatColor.GREEN + "" + ChatColor.BOLD + "Сундук смерти открылся! Успей забрать лут!");

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (activeChestLocation != null) {
                    forceRemoveChest();
                    Bukkit.broadcastMessage(ChatColor.RED + "Сундук смерти исчез.");
                }
            }, timedeleteopen * 20L);
        }, timeopen * 20L);
    }

    private void forceRemoveChest() {
        if (activeChestLocation != null) {
            Block block = activeChestLocation.getBlock();
            if (block.getType() == Material.ENDER_CHEST) block.setType(Material.AIR);
        }
        removeTimerDisplay();
        removeOpenDisplay();
        activeChestLocation = null;
        chestIsOpen = false;
        deathChestInventory = null;
    }

    public void startAutoSpawn() {
        if (autoSpawnTaskId != -1) Bukkit.getScheduler().cancelTask(autoSpawnTaskId);
        int intervalMinutes = config.getInt("Время.интервал-авто-спавна-минуты", 60);
        long intervalTicks = intervalMinutes * 60L * 20L;
        autoSpawnTaskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            spawnEnderChest(null);
        }, intervalTicks, intervalTicks);
        plugin.getLogger().info("Авто-спавн каждые " + intervalMinutes + " минут запущен.");
    }

    public void stopAutoSpawn() {
        if (autoSpawnTaskId != -1) {
            Bukkit.getScheduler().cancelTask(autoSpawnTaskId);
            autoSpawnTaskId = -1;
        }
    }

    public void notifyBeforeSpawn() {
        Bukkit.broadcastMessage(ChatColor.YELLOW + "Скоро появится сундук смерти! Будьте готовы!");
    }

    private void createTimerDisplay(Location location, int seconds) {
        Location displayLoc = location.clone().add(0.5, 1.8, 0.5);
        World world = displayLoc.getWorld();
        if (world == null) return;
        TextDisplay display = (TextDisplay) world.spawnEntity(displayLoc, EntityType.TEXT_DISPLAY);
        applyDisplayStyle(display);
        display.setText(ChatColor.RED + "Закрыт\n" + ChatColor.AQUA + formatTime(seconds));
        timerDisplayUUID = display.getUniqueId();
        int[] remaining = {seconds};
        timerTaskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            remaining[0]--;
            if (timerDisplayUUID == null) { Bukkit.getScheduler().cancelTask(timerTaskId); return; }
            Entity ent = Bukkit.getEntity(timerDisplayUUID);
            if (ent instanceof TextDisplay td && remaining[0] > 0) {
                td.setText(ChatColor.RED + "Закрыт\n" + ChatColor.AQUA + formatTime(remaining[0]));
            } else {
                Bukkit.getScheduler().cancelTask(timerTaskId);
            }
        }, 20L, 20L);
    }

    private void createOpenDisplay(Location location, int seconds) {
        Location displayLoc = location.clone().add(0.5, 1.8, 0.5);
        World world = displayLoc.getWorld();
        if (world == null) return;
        TextDisplay display = (TextDisplay) world.spawnEntity(displayLoc, EntityType.TEXT_DISPLAY);
        applyDisplayStyle(display);
        display.setText(ChatColor.GREEN + "Открыт!\n" + ChatColor.YELLOW + formatTime(seconds));
        openDisplayUUID = display.getUniqueId();
        int[] remaining = {seconds};
        openTimerTaskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            remaining[0]--;
            if (openDisplayUUID == null) { Bukkit.getScheduler().cancelTask(openTimerTaskId); return; }
            Entity ent = Bukkit.getEntity(openDisplayUUID);
            if (ent instanceof TextDisplay td && remaining[0] > 0) {
                td.setText(ChatColor.GREEN + "Открыт!\n" + ChatColor.YELLOW + formatTime(remaining[0]));
            } else {
                Bukkit.getScheduler().cancelTask(openTimerTaskId);
            }
        }, 20L, 20L);
    }

    private void applyDisplayStyle(TextDisplay display) {
        display.setBillboard(Display.Billboard.CENTER);
        display.setDefaultBackground(false);
        display.setShadowed(true);
        display.setAlignment(TextDisplay.TextAlignment.CENTER);
        display.setTransformation(new Transformation(
                new Vector3f(0, 0, 0),
                new AxisAngle4f(0, 0, 1, 0),
                new Vector3f(1.5f, 1.5f, 1.5f),
                new AxisAngle4f(0, 0, 1, 0)
        ));
    }

    private void removeTimerDisplay() {
        if (timerDisplayUUID != null) {
            Entity ent = Bukkit.getEntity(timerDisplayUUID);
            if (ent != null) ent.remove();
            timerDisplayUUID = null;
        }
        if (timerTaskId != -1) { Bukkit.getScheduler().cancelTask(timerTaskId); timerTaskId = -1; }
    }

    private void removeOpenDisplay() {
        if (openDisplayUUID != null) {
            Entity ent = Bukkit.getEntity(openDisplayUUID);
            if (ent != null) ent.remove();
            openDisplayUUID = null;
        }
        if (openTimerTaskId != -1) { Bukkit.getScheduler().cancelTask(openTimerTaskId); openTimerTaskId = -1; }
    }

    private String formatTime(int totalSeconds) {
        int minutes = totalSeconds / 60;
        int secs = totalSeconds % 60;
        return minutes > 0 ? minutes + "м " + secs + "с" : secs + "с";
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != Material.ENDER_CHEST) return;
        if (activeChestLocation == null) return;

        Location loc = event.getClickedBlock().getLocation();
        if (!loc.getWorld().equals(activeChestLocation.getWorld())) return;
        if (loc.getBlockX() != activeChestLocation.getBlockX()) return;
        if (loc.getBlockY() != activeChestLocation.getBlockY()) return;
        if (loc.getBlockZ() != activeChestLocation.getBlockZ()) return;

        event.setCancelled(true);

        if (!chestIsOpen) {
            event.getPlayer().sendMessage(ChatColor.RED + "Сундук ещё не открылся!");
            return;
        }

        UUID uid = event.getPlayer().getUniqueId();
        long now = System.currentTimeMillis();
        if (lastClickTimes.containsKey(uid) && now - lastClickTimes.get(uid) < 500) return;
        lastClickTimes.put(uid, now);

        if (deathChestInventory != null) {
            event.getPlayer().openInventory(deathChestInventory);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (deathChestInventory == null) return;
        if (!event.getInventory().equals(deathChestInventory)) return;
        if (event.getClickedInventory() != null && !event.getClickedInventory().equals(deathChestInventory)) {
            event.setCancelled(true);
        }
    }

    public void cleanup() {
        forceRemoveChest();
        stopAutoSpawn();
    }
}
