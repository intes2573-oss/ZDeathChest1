package com.example.zaltar;

import org.bukkit.plugin.java.JavaPlugin;

public class Zaltar extends JavaPlugin {

    private LootManager lootManager;
    private EnderChestManager enderChestManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.lootManager = new LootManager(this);
        this.enderChestManager = new EnderChestManager(this);

        getCommand("cc").setExecutor(new SaltarCommand(this));
        getCommand("ccloot").setExecutor(new AltLootCommand(this));
        getCommand("checkcc").setExecutor(new ChekSpCommand(this));
        getCommand("ccreload").setExecutor(new ReloadCommand(this));

        // Запускаем авто-спавн
        enderChestManager.startAutoSpawn();

        getLogger().info("ZAltar v1.1 включён!");
    }

    @Override
    public void onDisable() {
        if (enderChestManager != null) {
            enderChestManager.cleanup();
        }
        getLogger().info("ZAltar выключён.");
    }

    public LootManager getLootManager() {
        return lootManager;
    }

    public EnderChestManager getEnderChestManager() {
        return enderChestManager;
    }
}
