package com.example.zaltar;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SaltarCommand implements CommandExecutor {

    private final Zaltar plugin;

    public SaltarCommand(Zaltar plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // /cc         — спавнит сундук вручную
        // /cc start   — запускает авто-спавн
        // /cc stop    — останавливает авто-спавн

        if (args.length > 0) {
            switch (args[0].toLowerCase()) {
                case "start" -> {
                    plugin.getEnderChestManager().startAutoSpawn();
                    sender.sendMessage(ChatColor.GREEN + "Авто-спавн сундука запущен.");
                    return true;
                }
                case "stop" -> {
                    plugin.getEnderChestManager().stopAutoSpawn();
                    sender.sendMessage(ChatColor.YELLOW + "Авто-спавн остановлен.");
                    return true;
                }
            }
        }

        // Без аргументов — ручной спавн
        Player player = (sender instanceof Player p) ? p : null;
        plugin.getEnderChestManager().spawnEnderChest(player);
        if (player != null) player.sendMessage(ChatColor.GREEN + "Сундук заспавнен!");
        return true;
    }
}
